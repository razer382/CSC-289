/*
 * Branden Alder
 * 3/26/22
 */
package JavaMedicalLibrary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.mariadb.jdbc.*;

public class SQLDataAccess {
    //<editor-fold defaultstate="collapsed" desc="doesUserExist">
    // Checks if patient email is in DB.
    public static boolean isPatient(String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try{
            String query = "SELECT * FROM patients";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    if(resultSet.getString("Email").equalsIgnoreCase(email)){
                        return true;
                    }
                }}
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    // checks if employee is in DB
    public static boolean isEmployee(String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            String query = "SELECT * FROM employees";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    if(resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="logUser/EmployeeIn">
    // Logs patient in if info matches -- TODO - Need to edit after patient class made
    public static boolean logPatientIn(String email, String password) // Todo - Patient and employees can log in with both their email or their username
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try{
            String query = "SELECT * FROM patients";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            
            while(resultSet.next()){
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    // logs employee in
    public static boolean logEmployeeIn(String email, String password)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try{
            String query = "SELECT * FROM employees";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="DB Inserts">
    // Inserts new patients
    public static void insertNewPatient(String firstName, String lastName,
            String email, String password) throws SQLException
    {
        Connection connection = null;
        Statement statement = null;
        
        try{
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            
            String sqlText = "INSERT INTO patients (First Name, Last Name, Email, Password)"
                        + "VALUES(@fName, @lName, @email, @password)"; // Todo - this may not work.. finishing later.
            
            statement.executeUpdate(sqlText);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            statement.close();
            connection.close();
            //connection.closeConnection(connection, statement);
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Open/Close DB Connection Methods">
    public static Connection loadDatabase()
    {
        try{
            Class.forName("org.mariadb.jdbc.Driver");            
            Connection connection = DriverManager.getConnection
        ("jdbc:mariadb://127.0.0.1:3306/medical", "root", "password"); // Todo - change later, login info shouldnt be in code
            return connection;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    // Closes database connection when you're getting info from DB
    public static void closeConnection(Connection connection, Statement statement,
            ResultSet resultSet)
    {
        try{
            resultSet.close();
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    // Closes database connection when you arent getting info from DB.
    public static void closeConnection(Connection connection, Statement statement) 
    {
        try{
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    //</editor-fold>
}
