package javamedical.objects;

import java.util.ArrayList;

public class Patient {
    //<editor-fold defaultstate="collapsed" desc="Fields">
    private String patientID;
    private String lastName;
    private String firstName;
    private String gender;
    private String email;
    private String birthDate;
    private Doctor patientDoctor; // Todo - Remove after model fits current need and functionality changed depending on what UI man wants to do and investors not giving me money want
    private ArrayList<Doctor> patientDoctors; // TODO - add getters and setters for this
    private ArrayList<Appointment> patientAppointments;
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Patient(){
        patientID = "N/A";
        lastName = "N/A";
        firstName = "N/A";
        gender = "N/A";
        email = "N/A";
        birthDate = "N/A";
        patientDoctor = new Doctor(); // Todo - remove this also
        patientDoctors = new ArrayList<>();
        patientAppointments = new ArrayList<>();
    }
    public Patient(String patientId, String lastName, String firstName, String gender,
            String email, String birthDate, Doctor doctor)
    {
        this.patientID = patientId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.gender = gender;
        this.email = email;
        this.birthDate = birthDate;
        this.patientDoctor = doctor; // Todo - remove this as well << EDIT CONSTRUCTOR PARAMETERS >>
        this.patientDoctors = new ArrayList<>();
        this.patientAppointments = new ArrayList<>();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    public String getPatientID()
    {
        return patientID;
    }
    public void setPatientID(String patientID)
    {
        this.patientID = patientID;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;  
    }

    public String getGender()
    {
        return gender;
    }
    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getEmail()
    {
        return email;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getBirthDate()
    {
        return birthDate;
    }
    public void setBirthDate(String birthDate)
    {
        this.birthDate = birthDate;
    }
    //</editor-fold>
}
