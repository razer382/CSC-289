// Branden Alder
// 3/16/21
package javamedical.objects;


public class Appointment {
    private String appointmentDate;
    private String patientID;
    private String appointmentTime; // Todo - change after you check on the right datatype to pull from mariadb that fits todays STANDARDS
    private String doctorID;
    
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Appointment()
    {
        appointmentDate = "N/A";
        patientID = "N/A";
        appointmentTime = "00:00:00";
        doctorID = "N/A";
    }
    public Appointment(String appointmentDate, String patientId,
            String appointmentTime, String doctorID)
    {
        this.appointmentDate = appointmentDate;
        this.patientID = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.doctorID = doctorID;
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    public String getAppointmentDate()
    {
        return appointmentDate;
    }
    public void setAppointmentDate(String appointmentDate)
    {
        this.appointmentDate = appointmentDate;
    }
    
    public String getPatientID()
    {
        return patientID;
    }
    public void setPatientID(String patientID)
    {
        this.patientID = patientID;
    }
    
    public String getAppointmentTime()
    {
        return appointmentTime;
    }
    public void setAppointmentTime(String appointmentTime)
    {
        this.appointmentTime = appointmentTime;
    }
    
    public String getDoctorID()
    {
        return doctorID;
    }
    public void setDoctorID(String doctorID)
    {
        this.doctorID = doctorID;
    }
    
    //</editor-fold>
}
