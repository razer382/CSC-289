package javamedical.objects;

import java.util.ArrayList;

public class Doctor {
    //<editor-fold defaultstate="collapsed" desc="Fields">
    private String doctorID;
    private String lastName;
    private String firstName;
    private String email;
    private ArrayList<Patient> patients;
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Doctor()
    {
        doctorID = "";
        lastName = "";
        firstName = "";
        email = "";
        this.patients = new ArrayList<>();
    }
    
    public Doctor(String doctorID, String lastName, String firstName, String email)
    {
        doctorID = "";
        lastName = "";
        firstName = "";
        email = "";
        this.patients = new ArrayList<>();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    public String getDoctorID()
    {
        return doctorID;
    }
    public void setDoctorID(String doctorID)
    {
        this.doctorID = doctorID;
    }
    
    
    public String getLastName()
    {
        return lastName;
    }
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    
    public String getEmail()
    {
        return email;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    
    public void addNewPatient(Patient newPatient)
    {
        patients.add(newPatient);
    }
    public void removePatient(Patient patient)
    {
        patients.remove(patient);
    }
    //</editor-fold>
}
