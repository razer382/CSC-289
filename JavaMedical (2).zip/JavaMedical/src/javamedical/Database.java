package javamedical;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.mariadb.jdbc.*;
import javamedical.objects.*;

public class Database {
    // Used to verify whether login information is correct or not for a patient.
    public static boolean verifyPatientLogin(String email, String password)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try{
            String query = "SELECT * FROM patients";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(SQLException e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    // Used to verify whether login information is correct or not for an employee.
    public static boolean verifyEmployeeLogin(String email, String password)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try{
            String query = "SELECT * FROM employees";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(SQLException e){
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    public static void logPatientIn(Patient patient, String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try{
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM patients");
            
            if(resultSet.getString("Email").equalsIgnoreCase(email)){
                patient.setFirstName(resultSet.getString("First Name"));
                patient.setLastName(resultSet.getString("Last Name"));
                patient.setEmail(resultSet.getString("Email"));
                patient.setBirthDate(resultSet.getString("Date of Birth"));
                patient.setGender("Gender");
                patient.setPatientID(resultSet.getString("Patient ID"));
            }
        }
        catch(SQLException e)
        {
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
    }
    
    // Get's doctors information from DB and logs them in.
    public static void logEmployeeIn(Doctor doctor, String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try{
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM employees");
            
            while(resultSet.next()){
                if(resultSet.getString("Email").equalsIgnoreCase(email)){ // TODO - its an orm so probably a better way to do this
                    doctor.setDoctorID(resultSet.getString("DoctorID"));
                    doctor.setLastName(resultSet.getString("Last Name"));
                    doctor.setFirstName(resultSet.getString("First Name"));
                    
                    
                    // Todo - Add patients
                    resultSet = statement.executeQuery("SELECT * FROM patients");
                    while(resultSet.next()){
                        if(resultSet.getString("Doctor ID").equals(doctor.getDoctorID())){
                            doctor.addNewPatient(new Patient(resultSet.getString("PatientID"),
                            resultSet.getString("Last Name"), resultSet.getString("First Name"),
                            resultSet.getString("Gender"), resultSet.getString("Email"),
                            resultSet.getString("Date of Birth"), doctor));
                        }
                    }
                }
            }
        }
        catch(SQLException e)
        {
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
    }
    
    //<editor-fold defaultstate="collapsed" desc="Open/Close DB Connection Methods">
    public static Connection loadDatabase()
    {
        Connection connection = null;
        try{
            Class.forName("org.mariadb.jdbc.Driver");            
            connection = DriverManager.getConnection
        ("jdbc:mariadb://127.0.0.1:3306/medical", "root", "password");
            return connection;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    // Closes database connection when you're getting info from DB
    public static void closeConnection(Connection connection, Statement statement,
            ResultSet resultSet)
    {
        try{
            resultSet.close();
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    // Closes database connection when you arent getting info from DB.
    public static void closeConnection(Connection connection, Statement statement) 
    {
        try{
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    //</editor-fold>
}
