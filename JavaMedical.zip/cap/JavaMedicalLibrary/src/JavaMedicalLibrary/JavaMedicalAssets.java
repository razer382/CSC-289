/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package JavaMedicalLibrary;

public class JavaMedicalAssets
{
    public static void exit()
    {
        System.exit(0);
    }
}
