/*
 * Branden Alder
 * 3/26/22
 */
package JavaMedicalLibrary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import org.mariadb.jdbc.*;
import org.mariadb.jdbc.Driver;
import org.mariadb.jdbc.client.result.Result;
public class SQLDataAccess {
    //<editor-fold defaultstate="collapsed" desc="doesUserExist">
    // Checks if patient email is in DB.
    public static boolean isPatient(String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try{
            String query = "SELECT * FROM patients";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    JOptionPane.showMessageDialog(null, resultSet.getString(3));
                    if(resultSet.getString(3).equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnections(connection, statement, resultSet);
        }
        JOptionPane.showMessageDialog(null, "Account does not exist!");
        return false;
    }
    
    // checks if employee is in DB
    public static boolean isEmployee(String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            String query = "SELECT * FROM employees";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                    JOptionPane.showMessageDialog(null, resultSet.getString(3));
                    if(resultSet.getString(4).equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            closeConnections(connection, statement, resultSet);
        }
        JOptionPane.showMessageDialog(null, "Account does not exist!");
        return false;
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="checkUserPassword">
    // checks if patient password matches
    public static boolean checkPatientPassword()
    {
        try
        {
            
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    
    // checks if employee password matches
    public static boolean checkEmployeePassword()
    {
        try
        {
            
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    //</editor-fold>
    // Inserts new patients
    public static void insertNewPatient(String fName, String lName, String email,
            String password) throws SQLException
    {
        try{
            Connection connection = loadDatabase();
            java.sql.Statement statement = connection.createStatement();
            
            String sqlText = "INSERT INTO patients (First Name, Last Name, Email, Password)"
                        + "VALUES(@fName, @lName, @email, @password)";
            
            statement.executeUpdate(sqlText);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        
        
    }
    
    
    
    //<editor-fold defaultstate="collapsed" desc="DB Helpers">
    public static Connection loadDatabase()
    {
        try{
            Class.forName("org.mariadb.jdbc.Driver");            
            Connection connection = DriverManager.getConnection
        ("jdbc:mariadb://127.0.0.1:3306/javamedicaldb", "root", "password"); 
            return connection;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static void closeConnections(Connection connection, Statement statement,
            ResultSet resultSet)
    {
        try{
            resultSet.close();
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    //</editor-fold>
}
