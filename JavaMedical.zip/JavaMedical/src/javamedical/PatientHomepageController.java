/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package javamedical;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javamedical.objects.Appointment;
import javamedical.objects.Assets;
import javamedical.objects.Prescription;

public class PatientHomepageController implements Initializable 
{
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    //<editor-fold defaultstate="collapsed" desc="FXML">
    @FXML private TableView<Appointment> appointmentsTable;
    @FXML private TableColumn<Appointment, String> date;
    @FXML private TableColumn<Appointment, String> timeStart;
    @FXML private TableColumn<Appointment, String> doctorName;
    @FXML private TableColumn<Appointment, String> notes;
    @FXML private TableView<Prescription>  prescriptionsTable;
    @FXML private TableColumn<Prescription, String> prescriptionName;
    @FXML private TableColumn<Prescription, String> datePrescribed;
    @FXML private TableColumn<Prescription, String> doctorsNotes;
    //</editor-fold>
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //ObservableList<Appointment> appointmentsList = FXCollections.observableArrayList(Assets.patient.getAppointmentsList());
        // bind
        date.setCellValueFactory(new PropertyValueFactory<>("patientID"));
        timeStart.setCellValueFactory(new PropertyValueFactory<>("timeStart"));
        doctorName.setCellValueFactory(new PropertyValueFactory<>("doctorID"));
        notes.setCellValueFactory(new PropertyValueFactory<>("notes"));
        
        prescriptionName.setCellValueFactory(new PropertyValueFactory<>("prescriptionName"));
        datePrescribed.setCellValueFactory(new PropertyValueFactory<>("datePrescribed"));
        doctorsNotes.setCellValueFactory(new PropertyValueFactory<>("doctorsNotes"));
        
        //load data
        appointmentsTable.setItems(getAppointments());
        prescriptionsTable.setItems(getPrescriptions());
        
    }    
    
    public void homeScreen(ActionEvent event)throws Exception
    {
        root = FXMLLoader.load(getClass().getResource("/javamedical/JavaMedicalFXML.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Java Medical");
        stage.setScene(scene);
        stage.show();
    } 
    
    private ObservableList<Appointment> getAppointments()
    {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        Assets.patient.getAppointmentsList().forEach((appointment) -> {
            appointments.add(appointment);
        });
        return appointments;
    }
    
    private ObservableList<Prescription> getPrescriptions()
    {
        ObservableList<Prescription> prescriptions = FXCollections.observableArrayList();
        Assets.patient.getPrescriptionsList().forEach((prescription) -> {
           prescriptions.add(prescription);
        });
        return prescriptions;
    }
}
