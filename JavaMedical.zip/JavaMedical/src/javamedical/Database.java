package javamedical;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javamedical.objects.*;

public class Database {
    // Used to verify whether login information is correct or not for a patient.
    public static boolean verifyPatientLogin(String email, String password)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try
        {
            String query = "SELECT * FROM patients";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next())
            {
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    // Used to verify whether login information is correct or not for an employee.
    public static boolean verifyEmployeeLogin(String email, String password)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try
        {
            String query = "SELECT * FROM employees";
            
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next())
            {
                    if(resultSet.getString("Password").equals(password)
                            && resultSet.getString("Email").equalsIgnoreCase(email))
                    {
                        return true;
                    }
                }}
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    
    public static void logPatientIn(Patient patient, String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM patients");
            
            while(resultSet.next())
            {
                if(resultSet.getString("Email").equalsIgnoreCase(email)){
                    patient.setFirstName(resultSet.getString("First Name"));
                    patient.setLastName(resultSet.getString("Last Name"));
                    patient.setEmail(resultSet.getString("Email"));
                    patient.setBirthDate(resultSet.getString("Date of Birth"));
                    patient.setGender("Gender");
                    patient.setPatientID(resultSet.getString("PatientID"));
                    break;
                }
            }
            loadPatientPrescriptions(patient);
            loadPatientAppointments(patient);
        }
        catch(SQLException e)
        {
        }
        finally{
            closeConnection(connection, statement, resultSet);
        }
    }
    
    // Get's doctors information from DB and logs them in.
    public static void logEmployeeIn(Doctor doctor, String email)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM employees");
            
            while(resultSet.next())
            {
                if(resultSet.getString("Email").equalsIgnoreCase(email))
                { // TODO - its an orm so probably a better way to do this
                    doctor.setDoctorID(resultSet.getString("DoctorID"));
                    doctor.setLastName(resultSet.getString("Last Name"));
                    doctor.setFirstName(resultSet.getString("First Name"));
                    
                    resultSet = statement.executeQuery("SELECT * FROM patients");
                    int index = 0;
                    while(resultSet.next()){
                        if(resultSet.getString("Doctor ID").equals(doctor.getDoctorID())){
                            doctor.addNewPatient(new Patient(resultSet.getString("PatientID"),
                            resultSet.getString("Last Name"), resultSet.getString("First Name"),
                            resultSet.getString("Gender"), resultSet.getString("Email"),
                            resultSet.getString("Date of Birth"), doctor));
                            
                            loadPatientPrescriptions(doctor.getPatients().get(index));
                            loadPatientAppointments(doctor.getPatients().get(index));
                            index++;
                        }
                    }
                    
                    // Todo load patient prescriptions into object
                    loadEmployeePrescriptions(doctor);
                    // todo load patient appointments into object
                    loadEmployeeAppointments(doctor);
                }
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(connection, statement, resultSet);
        }
    }
    //<editor-fold defaultstate="collapsed" desc="Helper Methods">
    public static void loadEmployeePrescriptions(Doctor doctor)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("Select * from prescriptions where DoctorID = " + doctor.getDoctorID());
            
            while(resultSet.next())
            {
                if(resultSet.getString("DoctorID").equals(doctor.getDoctorID()))
                {
                    doctor.addNewPrescription(new Prescription(resultSet.getString("PrescribeID"),
                            resultSet.getString("Name"), resultSet.getString("Brand"),
                            resultSet.getString("descritption"), resultSet.getString("PatientID"),
                            resultSet.getString("DoctorID"), resultSet.getString("Patient First Name"),
                            resultSet.getString("Patient Last Name"), 
                            resultSet.getString("Pharmacy"), resultSet.getString("Date Perscribed"),
                            Integer.parseInt(resultSet.getString("Refills")), resultSet.getString("Med Notes")));
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void loadEmployeeAppointments(Doctor doctor)
    {
        // todo load employee appointments into class
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM appointments where DoctorID = " + doctor.getDoctorID());
            
            while(resultSet.next())
            {
                if(resultSet.getString("DoctorID").equals((doctor.getDoctorID())))
                {
                    doctor.addNewAppointment(new Appointment(resultSet.getString("AppointmentID"),
                    resultSet.getString("PatientID"), resultSet.getString("DoctorID"),
                    resultSet.getString("TimeStart"), resultSet.getString("TimeEnd"),
                    resultSet.getString("Date"), resultSet.getString("Notes")));
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static void loadPatientPrescriptions(Patient patient)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM prescriptions where PatientID = " + patient.getPatientID());
            
            while(resultSet.next())
            {
                patient.addNewPrescription(new Prescription(resultSet.getString("PrescribeID"),
                            resultSet.getString("Name"), resultSet.getString("Brand"),
                            resultSet.getString("Descritption"), resultSet.getString("PatientID"),
                            resultSet.getString("DoctorID"), resultSet.getString("Patient First Name"),
                            resultSet.getString("Patient Last Name"), 
                            resultSet.getString("Pharmacy"), resultSet.getString("Date Perscribed"),
                            Integer.parseInt(resultSet.getString("Refills")), resultSet.getString("Med Notes")));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void loadPatientAppointments(Patient patient)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM appointments where PatientID = " + patient.getPatientID());
            
            while(resultSet.next())
            {
                if(resultSet.getString("PatientID").equals(patient.getPatientID()))
                {
                    patient.addNewAppointment(new Appointment(resultSet.getString("AppointmentID"),
                    resultSet.getString("PatientID"), resultSet.getString("DoctorID"),
                    resultSet.getString("TimeStart"), resultSet.getString("TimeEnd"),
                    resultSet.getString("Date"), resultSet.getString("Notes")));
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Insert Methods">
    public static boolean insertNewPatient(String patientLastName, String patientFirstName, String patientSSN,
        String patientGender, String patientPhoneNumber, String patientEmail, String setPassword, String patientDOB)
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        String sql = "INSERT INTO patients VALUES ('0','" + patientLastName + "','" + patientFirstName 
                + "','" + patientSSN +"','" + patientGender +"','" + patientPhoneNumber 
                + "','" + patientEmail + "','" + setPassword + "','" + patientDOB +"');";
        String sql2 = "INSERT INTO patients VALUES ('0','" + patientLastName + "','" + patientFirstName 
                + "','" + patientSSN +"','" + patientGender +"','" + patientPhoneNumber 
                + "','" + patientEmail + "','" + setPassword + "','" + patientDOB +"','" + "" + "','" + "" + "','" + " " + "',' ');";
        System.out.println(sql2);
        try
        {
            connection = loadDatabase();
            statement = (Statement) connection.createStatement();
            statement.executeUpdate("SET FOREIGN_KEY_CHECKS=0");
            statement.executeUpdate(sql2);
            statement.executeUpdate("SET FOREIGN_KEY_CHECKS=1");
                   return true;
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(connection, statement, resultSet);
        }
        return false;
    }
    public static void insertNewPrescription()
    {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try
        {
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(connection, statement, resultSet);
        }
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Open/Close DB Connection Methods">
    public static Connection loadDatabase()
    {
        Connection connection = null;
        try{
            Class.forName("org.mariadb.jdbc.Driver");            
            connection = DriverManager.getConnection
        ("jdbc:mariadb://127.0.0.1:3306/medical", "root", "password");
            return connection;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    // Closes database connection when you're getting info from DB
    public static void closeConnection(Connection connection, Statement statement,
            ResultSet resultSet)
    {
        try{
            resultSet.close();
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    // Closes database connection when you arent getting info from DB.
    public static void closeConnection(Connection connection, Statement statement) 
    {
        try{
            statement.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    //</editor-fold>
}
