/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package javamedical;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javamedical.objects.Assets;

public class EmployeeLoginScreenController implements Initializable 
{
    @FXML
    private Label loginstatus;
    @FXML
    private TextField enterusername;
    @FXML
    private TextField enterpassword;
    
    private Stage stage;
    private Scene scene;
    private Parent root;

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    
    
    public void employeeLogin(ActionEvent event) throws Exception
    {
        if (Database.verifyEmployeeLogin(enterusername.getText(), enterpassword.getText()))
        {
            Database.logEmployeeIn(Assets.doctor, enterusername.getText());
            root = FXMLLoader.load(getClass().getResource("/javamedical/EmployeeHomepage.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setTitle("Java Medical");
            stage.setScene(scene);
            stage.show();
        } else
        {
            loginstatus.setText("Incorrect Username/Password");
        }
    }
    
    public void homeScreen(ActionEvent event)throws Exception
    {
        root = FXMLLoader.load(getClass().getResource("/javamedical/JavaMedicalFXML.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Java Medical");
        stage.setScene(scene);
        stage.show();
    } 
    
}
