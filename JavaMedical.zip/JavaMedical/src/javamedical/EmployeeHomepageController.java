/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package javamedical;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javamedical.objects.Assets;
import javamedical.objects.Patient;

public class EmployeeHomepageController implements Initializable 
{   
    //<editor-fold defaultstate="collapsed" desc="FXML">
    @FXML private TableView<Patient> patientsTable;
    @FXML private TableColumn<Patient, String> patientID;
    @FXML private TableColumn<Patient, String> firstName;
    @FXML private TableColumn<Patient, String> lastName;
    @FXML private TableColumn<Patient, String> gender;
    @FXML private TableColumn<Patient, String> email;
    @FXML private TableColumn<Patient, String> dateOfBirth;
    
    //</editor-fold>
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // Bind data
        patientID.setCellValueFactory(new PropertyValueFactory("patientID"));
        firstName.setCellValueFactory(new PropertyValueFactory("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory("lastName"));
        gender.setCellValueFactory(new PropertyValueFactory("gender"));
        email.setCellValueFactory(new PropertyValueFactory("email"));
        dateOfBirth.setCellValueFactory(new PropertyValueFactory("dateOfBirth"));
        // Load data
        patientsTable.setItems(getPatients());
    }    
    
    public void homeScreen(ActionEvent event)throws Exception
    {
        root = FXMLLoader.load(getClass().getResource("/javamedical/JavaMedicalFXML.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    } 
    
    public void openPatientChart(MouseEvent event)throws Exception
    {
        if(event.getClickCount() == 2 && patientsTable.getSelectionModel().getSelectedItem() != null)
        {
            Assets.index = patientsTable.getSelectionModel().getSelectedIndex();
            
            root = FXMLLoader.load(getClass().getResource("/javamedical/EmployeeChartView.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
        else
        {
            // todo add function for empty rows/empty columns
        }
        
    }
    
    private ObservableList<Patient> getPatients()
    {
        ObservableList<Patient> patients = FXCollections.observableArrayList();
        Assets.doctor.getPatients().forEach((patient) -> {
            patients.add(patient);
        });
        return patients;
    }
    
}


