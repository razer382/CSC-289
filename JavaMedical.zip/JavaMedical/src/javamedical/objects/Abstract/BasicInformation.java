package javamedical.objects.Abstract;

public interface BasicInformation {
    
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    abstract String getFirstName();
    
    abstract void setFirstName(String firstName);
    
    abstract String getLastName();
    abstract void setLastName(String lastName);
    
    abstract String getEmail();
    abstract void setEmail(String email);
    
    abstract String getIdNumber();
    abstract void setIdNumber(String idNumber);
    //</editor-fold>
}
