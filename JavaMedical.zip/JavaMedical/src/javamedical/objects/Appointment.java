package javamedical.objects;

public class Appointment {
    private String appointmentID;
    private String patientID;
    private String doctorID;
    private String timeStart;
    private String timeEnd;
    private String date; // DD-MM-YY
    private String notes; 
    
    public Appointment()
    {
        
    }
    public Appointment(String appointmentID, String patientID, String doctorID,
            String timeStart, String timeEnd, String date, String notes)
    {
        
    }
    
    public String getAppointmentID()
    {
        return appointmentID;
    }
    public void setAppointmentID(String appointmentID)
    {
        this.appointmentID = appointmentID;
    }
    
    public String getPatientID()
    {
        return patientID;
    }
    public void setPatientID(String patientID)
    {
        this.patientID = patientID;
    }
    
    public String getDoctorID()
    {
        return doctorID;
    }
    public void setDoctorID(String doctorID)
    {
        this.doctorID = doctorID;
    }
    
    public String getTimeStart()
    {
        return timeStart;
    }
    public void setTimeStart(String timeStart)
    {
        this.timeStart = timeStart;
    }
    
    public String getTimeEnd()
    {
        return timeEnd;
    }
    public void setTimeEnd(String timeEnd)
    {
        this.timeEnd = timeEnd;
    }
    
    public String getDate()
    {
        return date;
    }
    public void setDate(String date)
    {
        this.date = date;
    }
    
    public String getNotes()
    {
        return notes;
    }
    public void setNotes(String notes)
    {
        this.notes = notes;
    }
}
