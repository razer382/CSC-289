// Branden Alder
// 3/16/21
package javamedical.objects;

public class Appointment {
   //<editor-fold defaultstate="collapsed" desc="Fields">
    private String appointmentID;
    private String patientID;
    private String doctorID;
    private String appointmentDate;
    private String appointmentStartTime; // Todo - just add a method to check if its after 12. ( if so add PM else AM)
    private String appointmentEndTime;
    private String appointmentNotes;
    //</editor-fold>
    
   //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Appointment()
    {
        appointmentID = "N/A";
        patientID = "N/A";
        doctorID = "N/A";
        appointmentDate = "N/A";
        appointmentStartTime = "00:00:00";
        appointmentEndTime = "00:00:00";
        appointmentNotes = "N/A";
    }
    public Appointment(String appointmentID, String patientID, String doctorID,
            String appointmentDate, String appointmentStartTime, 
            String appointmentEndTime, String appointmentNotes)
    {
        this.appointmentID = appointmentID;
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.appointmentDate = appointmentDate;
        this.appointmentStartTime = appointmentStartTime;
        this.appointmentEndTime  = appointmentEndTime;
        this.appointmentNotes = appointmentNotes;
    }
    //</editor-fold>
   //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
   public String getApppointmentID()
   {
       return appointmentID;
   }
   public void setAppointmentID(String appointmentID)
   {
       this.appointmentID = appointmentID;
   }
   
   public String getPatientID()
   {
       return patientID;
   }
   public void setPatientID(String patientID)
   {
       this.patientID = patientID;
   }
   
   public String getDoctorID()
   {
       return doctorID;
   }
   public void setDoctorID(String doctorID)
   {
       this.doctorID = doctorID;
   }
   public String getAppointmentDate()
   {
       return appointmentDate;
   }
   public void setAppointmentDate()
   {
       this.appointmentDate = appointmentDate;
   }
   public String getAppointmentStartTime()
   {
       return appointmentStartTime;
   }
   public void setAppointmentStartTime(String appointmentStartTime)
   {
       appointmentStartTime = appointmentStartTime;
   }
   public String getAppointmentEndTime()
   {
       return appointmentEndTime;
   }
   public void setAppointmentEndTime(String appointmentEndTime)
   {
       this.appointmentEndTime = appointmentEndTime;
   }
    //</editor-fold>
   
   //<editor-fold defaultstate="collapsed" desc="Helper Methods">
   
   //</editor-fold>
}
