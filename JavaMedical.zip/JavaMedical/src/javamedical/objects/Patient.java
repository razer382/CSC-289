package javamedical.objects;

import java.util.ArrayList;
import javamedical.objects.Abstract.BasicInformation;

public class Patient implements BasicInformation{
    //<editor-fold defaultstate="collapsed" desc="Fields">
    private String patientID;
    private String lastName;
    private String firstName;
    private String gender;
    private String email;
    private String birthDate;
    private Doctor patientDoctor; // Todo - Remove after model fits current need and functionality changed depending on what UI man wants to do and investors not giving me money want
    private ArrayList<Doctor> patientDoctors; // TODO - add getters and setters for this
    private ArrayList<Appointment> patientAppointments;
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Patient(){
        patientID = "N/A";
        lastName = "N/A";
        firstName = "N/A";
        gender = "N/A";
        email = "N/A";
        birthDate = "N/A";
        patientDoctor = new Doctor(); // Todo - remove this also
        patientDoctors = new ArrayList<>();
        patientAppointments = new ArrayList<>();
    }
    public Patient(String patientId, String lastName, String firstName, String gender,
            String email, String birthDate, Doctor doctor)
    {
        this.patientID = patientId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.gender = gender;
        this.email = email;
        this.birthDate = birthDate;
        this.patientDoctor = doctor; // Todo - remove this as well << EDIT CONSTRUCTOR PARAMETERS >>
        this.patientDoctors = new ArrayList<>();
        this.patientAppointments = new ArrayList<>();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    public String getBirthDate()
    {
        return birthDate;
    }
    public void setBirthDate(String birthDate)
    {
        this.birthDate = birthDate;
    }
    
    public String getGender()
    {
        return gender;
    }
    public void setGender(String gender)
    {
        this.gender = gender;
    }
    @Override
    public String getFirstName() 
    {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) 
    {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() 
    {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) 
    {
        this.lastName = lastName;
    }

    @Override
    public String getEmail() 
    {
        return email;
    }

    @Override
    public void setEmail(String email) 
    {
        this.email = email;
    }

    @Override
    public String getIdNumber() 
    {
        return patientID;
    }

    @Override
    public void setIdNumber(String idNumber) 
    {
        patientID = idNumber;
    }
    
    public void addPatientAppointment(Appointment appointment)
    {
        patientAppointments.add(appointment);
    }
    public void removePatientAppointment(Appointment appointment)
    {
        patientAppointments.remove(appointment);
    }
    public void removePatientAppointmentIndex(int index)
    {
        patientAppointments.remove(index);
    }
    
    public void addPatientDoctor(Doctor doctor)
    {
        patientDoctors.add(doctor);
    }
    public void removePatientDoctor(Doctor doctor)
    {
        patientDoctors.remove(doctor);
    }
    public void removePatientDoctorIndex(int index)
    {
        patientDoctors.remove(index);
    }
    //</editor-fold>
}
