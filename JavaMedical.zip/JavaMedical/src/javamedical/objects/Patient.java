package javamedical.objects;

import java.util.ArrayList;
import java.util.List;
import javafx.collections.ObservableList;

public class Patient {
    //<editor-fold defaultstate="collapsed" desc="Fields">
    private String patientID;
    private String lastName;
    private String firstName;
    private String gender;
    private String email;
    private String dateOfBirth;
    private Doctor patientDoctor;
    private List<Appointment> appointments;
    private List<Prescription> prescriptions;
    
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Patient(){
        patientID = "N/A";
        lastName = "N/A";
        firstName = "N/A";
        gender = "N/A";
        email = "N/A";
        dateOfBirth = "N/A";
        patientDoctor = new Doctor();
        appointments = new ArrayList<>();
        prescriptions = new ArrayList<>();
    }
    public Patient(String patientId, String lastName, String firstName, String gender,
            String email, String birthDate, Doctor doctor)
    {
        this.patientID = patientId;
        this.lastName = lastName;
        this.firstName = firstName;
        this.gender = gender;
        this.email = email;
        this.dateOfBirth = birthDate;
        this.patientDoctor = doctor;
        appointments = new ArrayList<>();
        prescriptions = new ArrayList<>();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    public String getPatientID()
    {
        return patientID;
    }
    public void setPatientID(String patientID)
    {
        this.patientID = patientID;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    
    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;  
    }

    
    public String getGender()
    {
        return gender;
    }
    public void setGender(String gender)
    {
        this.gender = gender;
    }

    
    public String getEmail()
    {
        return email;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    
    public String getDateOfBirth()
    {
        //dd-mm-yy
        String[] split = dateOfBirth.split("-");
        return split[2] + "-" + split[1] + "-" + split[0];
    }
    public void setBirthDate(String birthDate)
    {
        this.dateOfBirth = birthDate;
    }
    
    public List<Prescription> getPrescriptionsList()
    {
        return prescriptions;
    }
    public void addNewPrescription(Prescription prescription)
    {
        prescriptions.add(prescription);
    }
    public void removePrescription(Prescription prescription)
    {
        prescriptions.remove(prescription);
    }
    public List<Appointment> getAppointmentsList()
    {
        return appointments;
    }
    public void addNewAppointment(Appointment appointment)
    {
        appointments.add(appointment);
    }
    public void removeAppointment(Appointment appointment)
    {
        appointments.remove(appointment);
    }

    //</editor-fold>
}
