package javamedical.objects;

public class Assets {
    public static Doctor doctor = new Doctor();
    public static Patient patient = new Patient();
    public static int index;
}
