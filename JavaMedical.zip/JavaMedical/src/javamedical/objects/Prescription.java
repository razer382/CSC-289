package javamedical.objects;

public class Prescription {
    private String prescriptionID;
    private String prescriptionName;
    private String prescriptionBrand;
    private String description;
    private String patientID;
    private String doctorID;
    private String patientFirstName;
    private String patientLastName;
    private String pharmacy;
    private String datePrescribed;
    private Integer refills;
    private String doctorsNotes;
    public Prescription()
    {
        this.prescriptionID = "";
        this.prescriptionName = "";
        this.prescriptionBrand = "";
        this.description = "";
        this.patientID = "";
        this.doctorID = "";
        this.patientFirstName = "";
        this.patientLastName = "";
        this.pharmacy = "";
        this.datePrescribed = "";
        this.refills = 0;
        this.doctorsNotes = "";
    }
    
    public Prescription(String prescriptionID, String prescriptionName, String prescriptionBrand,
            String description, String patientID, String doctorID, String patientFirstName,
            String patientLastName, String pharmacy, String datePrescribed, Integer refills, String doctorsNotes )
    {
        this.prescriptionID = prescriptionID;
        this.prescriptionName = prescriptionName;
        this.prescriptionBrand = prescriptionBrand;
        this.description = description;
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.patientFirstName = patientFirstName;
        this.patientLastName = patientLastName;
        this.pharmacy = pharmacy;
        this.datePrescribed = datePrescribed;
        this.refills = refills;
        this.doctorsNotes = doctorsNotes;
    }
    
    public String getPrescriptionID()
    {
        return prescriptionID;
    }
    public void setPrescriptionID(String prescriptionID)
    {
        this.prescriptionID = prescriptionID;
    }
    
    public String getPrescriptionName()
    {
        return prescriptionName;
    }
    public void setPrescriptionName(String prescriptionName)
    {
        this.prescriptionName = prescriptionName;
    }
    
    public String getPrescriptionBrand()
    {
        return prescriptionBrand;
    }
    public void setPrescriptionBrand(String prescriptionBrand)
    {
        this.prescriptionBrand = prescriptionBrand;
    }
    
    public String getDescription()
    {
        return description;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    public String getPatientID()
    {
        return patientID;
    }
    public void setPatientID(String patientID)
    {
        this.patientID = patientID;
    }
    
    public String getDoctorID()
    {
        return doctorID;
    }
    public void setDoctorID(String doctorID)
    {
        this.doctorID = doctorID;
    }
    public String getPatientFirstName()
    {
        return patientFirstName;
    }
    public void setPatientFirstName(String patientFirstName)
    {
        this.patientFirstName = patientFirstName;
    }
    public String getPatientLastName()
    {
        return patientLastName;
    }
    public void setPatientLastName(String patientLastName)
    {
        this.patientLastName = patientLastName;
    }
    public String getPharmacy()
    {
        return pharmacy;
    }
    public void setPharmacy(String pharmacy)
    {
        this.pharmacy = pharmacy;
    }
    public String getDatePrescribed()
    {
        return datePrescribed;
    }
    public void setDatePrescribed(String datePrescribed)
    {
        this.datePrescribed = datePrescribed;
    }
    
    public Integer getRefills()
    {
        return refills;
    }
    public void setRefills(Integer refills)
    {
        this.refills = refills;
    }
    
    public String getDoctorsNotes()
    {
        return doctorsNotes;
    }
    public void setDoctorsNotes(String doctorsNotes)
    {
        this.doctorsNotes = doctorsNotes;
    }
}
