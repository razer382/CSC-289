package javamedical.objects;

import java.util.ArrayList;
import javamedical.objects.Abstract.BasicInformation;

public class Doctor implements BasicInformation {
    //<editor-fold defaultstate="collapsed" desc="Fields">
    private String doctorID;
    private String lastName;
    private String firstName;
    private String email;
    private ArrayList<Patient> patients;
    private ArrayList<Appointment> appointments;
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    public Doctor()
    {
        doctorID = "";
        lastName = "";
        firstName = "";
        email = "";
        this.patients = new ArrayList<>();
        this.appointments = new ArrayList<>();
    }
    
    public Doctor(String doctorID, String lastName, String firstName, String email)
    {
        doctorID = "";
        lastName = "";
        firstName = "";
        email = "";
        this.patients = new ArrayList<>();
        this.appointments = new ArrayList<>();
    }
    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Getters/Setters">
    
    @Override
    public String getFirstName() 
    {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) 
    {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() 
    {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) 
    {
        this.lastName = lastName;
    }

    @Override
    public String getEmail() 
    {
        return email;
    }

    @Override
    public void setEmail(String email) 
    {
        this.email = email;
    }

    @Override
    public String getIdNumber()
    {
        return doctorID;
    }
    @Override
    public void setIdNumber(String idNumber) 
    {
        this.doctorID = idNumber;
    }
    
    public void addNewPatient(Patient patient)
    {
        patients.add(patient);
    }
    public void removePatient(Patient patient)
    {
        patients.remove(patient);
    }
    public void removePatientAtIndex(int index)
    {
        patients.remove(index);
    }
    
    public void addNewAppointment(Appointment appointment)
    {
        appointments.add(appointment);
    }
    public void removeAppointment(Appointment appointment)
    {
        appointments.remove(appointment);
    }
    public void removeAppointmentAtIndex(int index)
    {
        appointments.remove(index);
    }
    //</editor-fold>
}
